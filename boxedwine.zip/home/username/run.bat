c:
cd "\Program Files\TI Education\Derive 6"
start Derive6.exe
